import { createFileRoute } from "@tanstack/react-router";
import { Landing } from "@/components/polpa/Landing";

const DESC =
  "Speciality coffee, freshly baked pastries, breakfast and brunch served daily in the heart of Hanley, Stoke-on-Trent.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Brisk Coffee Hanley — Hanley's favourite independent coffee shop" },
      { name: "description", content: DESC },
      { property: "og:title", content: "Brisk Coffee Hanley — Hanley's favourite independent coffee shop" },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "preload", as: "image", href: "/images/coffee/cup-takeaway.webp" }],
  }),
  component: Landing,
});
