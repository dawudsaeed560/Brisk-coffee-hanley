import { useEffect } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { HOURS, ORDER_URL, SHOP } from "@/components/polpa/data";
import { Perks } from "@/components/polpa/Perks";
import { Footer } from "@/components/polpa/FinalCta";
import { Gallery } from "@/components/polpa/Gallery";
import { Location } from "@/components/polpa/Location";
import { useOpenMenu } from "@/components/polpa/MenuDialog";
import { startSmoothScroll } from "@/components/polpa/motion";
import { Pill } from "@/components/polpa/Pill";
import { SplitReveal } from "@/components/polpa/SplitReveal";
import { Testimonials } from "@/components/polpa/Testimonials";
import { useTransitionNavigate } from "@/components/polpa/PageTransition";

const DESC = "Visit Brisk Coffee Hanley at 1–3 Lamb Street, Hanley. Opening hours, directions, photos and reviews.";

export const Route = createFileRoute("/visit")({
  head: () => ({
    meta: [
      { title: "Visit Brisk Coffee Hanley — Hours & directions" },
      { name: "description", content: DESC },
      { property: "og:title", content: "Visit Brisk Coffee Hanley — Hours & directions" },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CafeOrCoffeeShop",
          name: SHOP.name,
          telephone: SHOP.phone,
          email: SHOP.email,
          servesCuisine: ["Coffee", "Breakfast", "Brunch"],
          address: {
            "@type": "PostalAddress",
            streetAddress: "1–3 Lamb Street",
            addressLocality: "Hanley, Stoke-on-Trent",
            postalCode: "ST1 1PF",
            addressCountry: "GB",
          },
          openingHoursSpecification: [
            { "@type": "OpeningHoursSpecification", dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], opens: HOURS[0]?.opens, closes: HOURS[0]?.closes },
            { "@type": "OpeningHoursSpecification", dayOfWeek: ["Sunday"], opens: HOURS[1]?.opens, closes: HOURS[1]?.closes },
          ],
        }),
      },
    ],
  }),
  component: VisitPage,
});

function VisitPage() {
  const go = useTransitionNavigate();
  const openMenu = useOpenMenu();
  useEffect(() => startSmoothScroll(), []);
  return (
    <>
      <main className="bg-navy text-cream">
        <div className="px-5 pb-28 pt-8 md:px-10">
          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={() => go("/")}
              className="flex items-center gap-2 font-display text-2xl uppercase md:text-3xl"
            >
              BRISK <span aria-hidden className="text-lg">●</span>
            </button>
            <div className="flex gap-2 md:gap-3">
              <Pill size="sm" variant="cream" href={ORDER_URL} external ariaLabel="Order online (opens Brisk's ordering page)">
                Order ↗
              </Pill>
              <Pill size="sm" variant="lime" onClick={() => go("/")}>
                ← Back
              </Pill>
            </div>
          </div>

          <div className="mx-auto max-w-6xl pt-24">
            <p className="label-mono mb-6 text-lime">Open 7 days in Hanley</p>
            <SplitReveal as="h1" text={"COME SAY\nHELLO"} className="headline text-[18vw] md:text-[10vw]" />
            <p className="script -mt-2 -rotate-[4deg] text-[10vw] text-lime md:text-[5vw]">the kettle's always on</p>
            <div className="mt-10">
              <Pill size="md" variant="cream" onClick={openMenu}>
                View menu
              </Pill>
            </div>
            <Location />
            <Perks />
          </div>
        </div>
        <Gallery />
        <Testimonials />
      </main>
      <div className="bg-plum-deep text-cream">
        <Footer />
      </div>
    </>
  );
}
