import { describe, expect, it } from "vitest";
import { FLAVORS, flavorIndexFromProgress, progressForFlavor } from "@/components/polpa/data";

describe("flavor scenes", () => {
  it("shows the first flavor at the top of the section and the last at the bottom", () => {
    expect(flavorIndexFromProgress(0, 4)).toBe(0);
    expect(flavorIndexFromProgress(1, 4)).toBe(3);
  });

  it("switches flavor every quarter of the scroll for four flavors", () => {
    expect(flavorIndexFromProgress(0.24, 4)).toBe(0);
    expect(flavorIndexFromProgress(0.26, 4)).toBe(1);
    expect(flavorIndexFromProgress(0.74, 4)).toBe(2);
  });

  it("clicking a flavor icon scrolls to the middle of that flavor's scene", () => {
    FLAVORS.forEach((_, i) => {
      expect(flavorIndexFromProgress(progressForFlavor(i, FLAVORS.length), FLAVORS.length)).toBe(i);
    });
  });

  it("starts with flat white, then latte", () => {
    expect(FLAVORS[0]?.name).toBe("Flat White");
    expect(FLAVORS[1]?.name).toBe("Latte");
  });
});

describe("Brisk menu and hours", () => {
  it("lists all 12 menu items", async () => {
    const { MENU } = await import("@/components/polpa/data");
    expect(MENU.map((m) => m.name)).toEqual([
      "Espresso", "Flat White", "Cappuccino", "Latte", "Mocha", "Americano",
      "Iced Latte", "Hot Chocolate", "Breakfast Baps", "Paninis", "Fresh Pastries", "Cakes",
    ]);
  });

  it("uses the opening hours from their website (Mon–Sat 8–5:30, Sun 9–4)", async () => {
    const { HOURS } = await import("@/components/polpa/data");
    expect(HOURS.map((h) => [h.opens, h.closes])).toEqual([
      ["08:00", "17:30"],
      ["09:00", "16:00"],
    ]);
  });

  it("shows all six Why Choose Us features", async () => {
    const { STICKERS } = await import("@/components/polpa/data");
    expect(STICKERS.map((s) => s.label.toLowerCase())).toEqual([
      "speciality coffee", "freshly prepared food", "local ingredients",
      "friendly service", "free wifi", "dog friendly",
    ]);
  });

  it("shows the real student, NHS and loyalty offers", async () => {
    const { PERKS } = await import("@/components/polpa/data");
    const byId = Object.fromEntries(PERKS.map((p) => [p.id, p.big]));
    expect(byId["students"]).toBe("25%");
    expect(byId["nhs"]).toBe("10%");
    expect(byId["loyalty"]).toBe("10");
  });

  it("shows the Hanley Google rating, not Wolverhampton's", async () => {
    const { GOOGLE_RATING } = await import("@/components/polpa/data");
    expect([GOOGLE_RATING.score, GOOGLE_RATING.count]).toEqual(["4.2", 593]);
  });

  it("links Order online to their existing ordering page", async () => {
    const { ORDER_URL } = await import("@/components/polpa/data");
    expect(ORDER_URL).toBe("https://briskcoffee.co/order-online/");
  });
});

describe("reviews", () => {
  it("match briskcoffee.co word for word and show first name + initial only", async () => {
    const { TESTIMONIALS } = await import("@/components/polpa/data");
    expect(TESTIMONIALS.map((t) => t.quote)).toEqual([
      "Had the salted cinnamon cloud latte and it was amazing. Nice fluffy head and great tasting coffee.",
      "Great relaxed atmosphere. Service is excellent staff are super friendly and helpful.",
    ]);
    expect(TESTIMONIALS.map((t) => t.name)).toEqual(["Mark B.", "Michael C."]);
  });
});
