import { useEffect, useRef, type ElementType } from "react";
import { cn } from "@/lib/utils";
import { ensureGsap, prefersReducedMotion } from "./motion";

interface SplitRevealProps {
  text: string;
  as?: ElementType;
  className?: string;
  lineClassName?: string;
  /** "mount" waits for `play`, "scroll" plays when scrolled into view */
  mode?: "mount" | "scroll";
  play?: boolean;
  delay?: number;
  stagger?: number;
}

/** Headline that slides up letter by letter from a mask. Use "\n" for line breaks. */
export function SplitReveal({
  text,
  as: Tag = "span",
  className,
  lineClassName,
  mode = "scroll",
  play = true,
  delay = 0,
  stagger = 0.035,
}: SplitRevealProps) {
  const ref = useRef<HTMLElement>(null);
  const lines = text.split("\n");

  useEffect(() => {
    const el = ref.current;
    if (!el || prefersReducedMotion()) return;
    const { gsap, ScrollTrigger } = ensureGsap();
    const chars = el.querySelectorAll("[data-char]");
    const ctx = gsap.context(() => {
      gsap.set(chars, { yPercent: 115 });
      if (mode === "scroll") {
        let played = false;
        const reveal = () => {
          if (played) return;
          played = true;
          gsap.to(chars, { yPercent: 0, duration: 1.1, ease: "expo.out", stagger, delay });
        };
        if (el.getBoundingClientRect().top < window.innerHeight * 0.88) reveal();
        else ScrollTrigger.create({ trigger: el, start: "top 88%", once: true, onEnter: reveal });
      }
    }, el);
    return () => ctx.revert();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const el = ref.current;
    if (!el || mode !== "mount" || !play || prefersReducedMotion()) return;
    const { gsap } = ensureGsap();
    const tween = gsap.to(el.querySelectorAll("[data-char]"), {
      yPercent: 0,
      duration: 1.2,
      ease: "expo.out",
      stagger,
      delay,
    });
    return () => {
      tween.kill();
    };
  }, [play, mode, delay, stagger]);

  return (
    <Tag ref={ref} aria-label={text.replace(/\n/g, " ")} className={className}>
      {lines.map((line, li) => (
        <span key={li} aria-hidden className={cn("block", lineClassName)}>
          {line.split(" ").map((word, wi, arr) => (
            <span key={wi}>
              <span className="mask-line">
                {Array.from(word).map((c, ci) => (
                  <span key={ci} data-char className="inline-block will-change-transform">
                    {c}
                  </span>
                ))}
              </span>
              {wi < arr.length - 1 ? " " : null}
            </span>
          ))}
        </span>
      ))}
    </Tag>
  );
}
