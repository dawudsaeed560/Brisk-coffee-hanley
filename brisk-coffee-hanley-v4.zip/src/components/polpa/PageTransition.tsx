import { createContext, useCallback, useContext, useRef, type ReactNode } from "react";
import { useNavigate, useRouterState } from "@tanstack/react-router";
import { ensureGsap, jumpToTop, prefersReducedMotion, smoothScrollTo } from "./motion";

type Destination = "/" | "/visit";
const TransitionContext = createContext<(to: Destination) => void>(() => {});

export const useTransitionNavigate = () => useContext(TransitionContext);

/** Quick ink crossfade between pages: fade in, swap the page at the top, fade out. */
export function PageTransitionProvider({ children }: { children: ReactNode }) {
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const overlayRef = useRef<HTMLDivElement>(null);
  const markRef = useRef<HTMLParagraphElement>(null);
  const busy = useRef(false);

  const go = useCallback(
    (to: Destination) => {
      if (busy.current || !overlayRef.current) return;
      if (pathname === to) {
        smoothScrollTo(0);
        return;
      }
      busy.current = true;
      const { gsap, ScrollTrigger } = ensureGsap();
      const reduced = prefersReducedMotion();
      const overlay = overlayRef.current;
      const mark = markRef.current;
      const reveal = () => {
        jumpToTop();
        // Let the new page lay out before measuring scroll scenes, then fade back in.
        requestAnimationFrame(() => {
          ScrollTrigger.refresh();
          gsap
            .timeline({ onComplete: () => void (busy.current = false) })
            .to(mark, { autoAlpha: 0, y: -8, duration: reduced ? 0 : 0.25, ease: "power2.in" })
            .to(overlay, { autoAlpha: 0, duration: reduced ? 0.01 : 0.5, ease: "power2.out" }, "<0.05");
        });
      };
      gsap
        .timeline()
        .set(mark, { autoAlpha: 0, y: 8 })
        .to(overlay, { autoAlpha: 1, duration: reduced ? 0.01 : 0.35, ease: "power2.inOut" })
        .to(mark, { autoAlpha: 1, y: 0, duration: reduced ? 0 : 0.25, ease: "power2.out" }, "<0.1")
        .add(() => {
          jumpToTop();
          navigate({ to }).then(reveal, reveal);
        });
    },
    [navigate, pathname],
  );

  return (
    <TransitionContext.Provider value={go}>
      {children}
      <div
        ref={overlayRef}
        className="invisible fixed inset-0 z-[150] flex items-center justify-center bg-ink opacity-0"
        role="status"
        aria-label="Loading"
      >
        <p ref={markRef} className="flex items-center gap-2 font-display text-4xl uppercase tracking-wide text-cream md:text-5xl">
          BRISK <span aria-hidden className="text-2xl text-loader">●</span>
        </p>
      </div>
    </TransitionContext.Provider>
  );
}
