import { useEffect, useState } from "react";
import { CupStage } from "./CupStage";
import { FinalCta } from "./FinalCta";
import { Flavors } from "./Flavors";
import { Intro } from "./Intro";
import { ensureGsap, lockScroll, prefersReducedMotion, session, startSmoothScroll } from "./motion";
import { Nav } from "./Nav";
import { Play } from "./Play";

export function Landing() {
  const [introDone, setIntroDone] = useState(false);

  useEffect(() => {
    const { ScrollTrigger } = ensureGsap();
    const stop = startSmoothScroll();
    if ("scrollRestoration" in history) history.scrollRestoration = "manual";

    let timer = 0;
    if (prefersReducedMotion() || session.introPlayed) {
      setIntroDone(true);
    } else {
      window.scrollTo(0, 0);
      lockScroll(true);
      timer = window.setTimeout(() => {
        session.introPlayed = true;
        lockScroll(false);
        setIntroDone(true);
      }, 1500);
    }

    const refresh = () => ScrollTrigger.refresh();
    void document.fonts?.ready.then(refresh);
    window.addEventListener("load", refresh);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener("load", refresh);
      lockScroll(false);
      stop();
    };
  }, []);

  return (
    <>
      <Intro done={introDone} />
      <Nav />
      <main>
        <CupStage introDone={introDone} />
        <Play />
        <Flavors />
        <FinalCta />
      </main>
    </>
  );
}
