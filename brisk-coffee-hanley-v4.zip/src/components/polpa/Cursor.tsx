import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import { ensureGsap, hasFinePointer, prefersReducedMotion } from "./motion";

// 16x16 pixel-art pointing hand: # = outline, o = fill
const HAND = [
  "....##..........",
  "...#oo#.........",
  "...#oo#.........",
  "...#oo#.........",
  "...#oo###.......",
  "...#oo#oo###....",
  "...#oo#oo#oo##..",
  ".###oo#oo#oo#o#.",
  "#oo#oooooooooo#.",
  "#ooooooooooooo#.",
  ".#oooooooooooo#.",
  "..#ooooooooooo#.",
  "..#oooooooooo#..",
  "...#ooooooooo#..",
  "....#oooooooo#..",
  "....##########..",
];

function PixelHand() {
  return (
    <svg viewBox="0 0 16 16" className="h-7 w-7" shapeRendering="crispEdges" aria-hidden>
      {HAND.flatMap((row, y) =>
        Array.from(row).map((c, x) =>
          c === "." ? null : (
            <rect
              key={`${x}-${y}`}
              x={x}
              y={y}
              width={1}
              height={1}
              className={c === "#" ? "fill-ink" : "fill-cream"}
            />
          ),
        ),
      )}
    </svg>
  );
}

const INTERACTIVE = 'a, button, [data-cursor="hand"], input, label, select, textarea';

/** Easing ring that becomes a pixel hand over anything you can click or grab. */
export function Cursor() {
  const ringRef = useRef<HTMLDivElement>(null);
  const handRef = useRef<HTMLDivElement>(null);
  const [enabled, setEnabled] = useState(false);
  const [hand, setHand] = useState(false);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!hasFinePointer()) return;
    setEnabled(true);
    document.documentElement.classList.add("has-cursor");
    return () => document.documentElement.classList.remove("has-cursor");
  }, []);

  useEffect(() => {
    if (!enabled || !ringRef.current || !handRef.current) return;
    const { gsap } = ensureGsap();
    const reduced = prefersReducedMotion();
    const ringX = gsap.quickTo(ringRef.current, "x", { duration: reduced ? 0 : 0.45, ease: "power3.out" });
    const ringY = gsap.quickTo(ringRef.current, "y", { duration: reduced ? 0 : 0.45, ease: "power3.out" });
    const handX = gsap.quickTo(handRef.current, "x", { duration: reduced ? 0 : 0.08, ease: "power3.out" });
    const handY = gsap.quickTo(handRef.current, "y", { duration: reduced ? 0 : 0.08, ease: "power3.out" });
    const move = (e: PointerEvent) => {
      if (e.pointerType !== "mouse") return;
      ringX(e.clientX);
      ringY(e.clientY);
      handX(e.clientX);
      handY(e.clientY);
      setVisible(true);
    };
    const over = (e: PointerEvent) => {
      const t = e.target as Element | null;
      setHand(Boolean(t?.closest?.(INTERACTIVE)));
    };
    const leave = () => setVisible(false);
    window.addEventListener("pointermove", move, { passive: true });
    window.addEventListener("pointerover", over, { passive: true });
    document.documentElement.addEventListener("pointerleave", leave);
    return () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerover", over);
      document.documentElement.removeEventListener("pointerleave", leave);
    };
  }, [enabled]);

  if (!enabled) return null;

  return (
    <>
      <div
        ref={ringRef}
        aria-hidden
        className="pointer-events-none fixed left-0 top-0 z-[200] mix-blend-difference"
      >
        <div
          className={cn(
            "-ml-4 -mt-4 h-8 w-8 rounded-full border-2 border-cream transition-[opacity,scale] duration-300",
            hand ? "scale-50 opacity-0" : "scale-100",
            !visible && "opacity-0",
          )}
        />
      </div>
      <div ref={handRef} aria-hidden className="pointer-events-none fixed left-0 top-0 z-[201]">
        <div
          className={cn(
            "-ml-2 -mt-0.5 transition-[opacity,scale] duration-200",
            hand && visible ? "scale-100 opacity-100" : "scale-50 opacity-0",
          )}
        >
          <PixelHand />
        </div>
      </div>
    </>
  );
}
