import { HOURS, SHOP } from "./data";
import { Pill } from "./Pill";

export function Location() {
  return (
    <section id="location" aria-label="Location and opening hours" className="mt-20">
      <div className="grid gap-10 md:grid-cols-2">
        <div>
          <p className="label-mono mb-4 text-lime">(01) Find us</p>
          <h2 className="headline text-6xl md:text-7xl">{SHOP.name}</h2>
          <address className="label-mono mt-6 not-italic leading-relaxed text-cream/80">{SHOP.address}</address>
          <ul className="mt-10 divide-y divide-cream/15 border-y border-cream/15">
            {HOURS.map((h) => (
              <li key={h.days} className="flex items-center justify-between py-4">
                <span className="label-mono text-cream/70">{h.days}</span>
                <span className="headline text-3xl">{h.hours}</span>
              </li>
            ))}
          </ul>
          <p className="label-mono mt-8 space-y-2 leading-relaxed text-cream/80">
            <a href={SHOP.phoneHref} className="block hover:text-lime">
              Call {SHOP.phone}
            </a>
            <a href={`mailto:${SHOP.email}`} className="block hover:text-lime">
              {SHOP.email}
            </a>
          </p>
          <div className="mt-10">
            <Pill size="lg" href={SHOP.directions} ariaLabel="Get directions on Google Maps">
              Get directions →
            </Pill>
          </div>
        </div>
        <div className="min-h-[22rem] overflow-hidden rounded-[1.25rem] border border-cream/15 shadow-pill">
          <iframe
            title="Map showing Brisk Coffee Hanley on Lamb Street"
            src={SHOP.map}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            className="h-full min-h-[22rem] w-full grayscale-[0.4] sepia-[0.35]"
          />
        </div>
      </div>
    </section>
  );
}
