import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import { FLAVORS, flavorIndexFromProgress, progressForFlavor } from "./data";
import type { FlavorShader } from "./flavorShader";
import { ensureGsap, prefersReducedMotion, smoothScrollTo } from "./motion";
import { useOpenMenu } from "./MenuDialog";
import { Pill } from "./Pill";

const N = FLAVORS.length;

/** One full-screen scene per signature drink, pinned while you scroll through them. */
export function Flavors() {
  const openMenu = useOpenMenu();
  const sectionRef = useRef<HTMLElement>(null);
  const hostRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<HTMLDivElement>(null);
  const shaderRef = useRef<FlavorShader | null>(null);
  const activeRef = useRef(0);
  const firstRef = useRef(true);
  const [active, setActive] = useState(0);

  // scroll position → active flavor
  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;
    const { ScrollTrigger } = ensureGsap();
    const st = ScrollTrigger.create({
      trigger: section,
      start: "top top",
      end: "bottom bottom",
      onUpdate: (self) => {
        const i = flavorIndexFromProgress(self.progress, N);
        if (i !== activeRef.current) {
          activeRef.current = i;
          setActive(i);
        }
      },
    });
    return () => st.kill();
  }, []);

  // lazy-load the shader near the viewport, pause it off-screen
  useEffect(() => {
    const section = sectionRef.current;
    const host = hostRef.current;
    if (!section || !host) return;
    let disposed = false;
    let loading = false;
    let visible = false;
    const io = new IntersectionObserver(
      ([entry]) => {
        visible = Boolean(entry?.isIntersecting);
        if (visible && !shaderRef.current && !loading) {
          loading = true;
          void import("./flavorShader").then(({ createFlavorShader }) => {
            if (disposed) return;
            const flavor = FLAVORS[activeRef.current] ?? FLAVORS[0]!;
            shaderRef.current = createFlavorShader(host, flavor.shader, prefersReducedMotion());
            shaderRef.current?.setRunning(visible);
          });
        }
        shaderRef.current?.setRunning(visible);
      },
      { rootMargin: "40% 0px" },
    );
    io.observe(section);
    const onVis = () => shaderRef.current?.setRunning(visible && !document.hidden);
    document.addEventListener("visibilitychange", onVis);
    return () => {
      disposed = true;
      io.disconnect();
      document.removeEventListener("visibilitychange", onVis);
      shaderRef.current?.destroy();
      shaderRef.current = null;
    };
  }, []);

  // crossfade colours, spin-swap the cup
  useEffect(() => {
    const flavor = FLAVORS[active];
    if (!flavor) return;
    shaderRef.current?.setColors(flavor.shader);
    if (firstRef.current) {
      firstRef.current = false;
      return;
    }
    const scene = sceneRef.current;
    if (!scene) return;
    const { gsap } = ensureGsap();
    const reduced = prefersReducedMotion();
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>("[data-cup]").forEach((el, i) => {
        if (i === active) {
          gsap.fromTo(
            el,
            { autoAlpha: 0, rotationY: reduced ? 0 : -140, scale: reduced ? 1 : 0.7, rotation: reduced ? 0 : -20 },
            { autoAlpha: 1, rotationY: 0, scale: 1, rotation: 0, duration: reduced ? 0.3 : 1, ease: "back.out(1.3)", delay: reduced ? 0 : 0.18 },
          );
        } else {
          gsap.to(el, { autoAlpha: 0, rotationY: reduced ? 0 : 140, scale: reduced ? 1 : 0.7, duration: reduced ? 0.2 : 0.4, ease: "power2.in" });
        }
      });
      gsap.utils.toArray<HTMLElement>("[data-ghost]").forEach((el, i) => {
        if (i === active) gsap.fromTo(el, { autoAlpha: 0, yPercent: 18 }, { autoAlpha: 1, yPercent: 0, duration: 0.9, ease: "expo.out" });
        else gsap.to(el, { autoAlpha: 0, yPercent: -18, duration: 0.4 });
      });
      gsap.utils.toArray<HTMLElement>("[data-copy]").forEach((el) => {
        const i = Number(el.dataset["copy"]);
        if (i === active) gsap.fromTo(el, { autoAlpha: 0, y: 24 }, { autoAlpha: 1, y: 0, duration: 0.7, delay: 0.2, ease: "power3.out" });
        else gsap.to(el, { autoAlpha: 0, y: -12, duration: 0.3 });
      });
    }, scene);
    return () => ctx.revert();
  }, [active]);

  const goTo = (i: number) => {
    const section = sectionRef.current;
    if (!section) return;
    const top = section.getBoundingClientRect().top + window.scrollY;
    const span = section.offsetHeight - window.innerHeight;
    smoothScrollTo(top + span * progressForFlavor(i, N));
  };

  const current = FLAVORS[active] ?? FLAVORS[0]!;

  return (
    <section
      ref={sectionRef}
      id="menu"
      className="relative bg-navy text-cream"
      style={{ height: `${N * 100}vh` }}
      aria-label="Signature drinks"
    >
      <div ref={sceneRef} className="sticky top-0 h-screen overflow-hidden">
        <div ref={hostRef} aria-hidden className="absolute inset-0" />

        {/* ghost words */}
        <div aria-hidden className="pointer-events-none absolute inset-0 flex items-center justify-center">
          {FLAVORS.map((f, i) => (
            <span
              key={f.id}
              data-ghost
              className="headline text-outline absolute whitespace-nowrap text-[30vw] text-cream/30 md:text-[24vw]"
              style={{ opacity: i === 0 ? 1 : 0, visibility: i === 0 ? "visible" : "hidden" }}
            >
              {f.name}
            </span>
          ))}
        </div>

        <p className="label-mono absolute left-5 top-24 md:left-10">(04) Signature drinks</p>
        <p className="label-mono absolute right-5 top-24 md:right-10" aria-live="polite">
          0{active + 1} / 0{N}
        </p>

        {/* selector */}
        <div className="absolute left-1/2 top-[19%] z-10 flex -translate-x-1/2 gap-3 md:top-[15%] md:gap-4" role="tablist" aria-label="Choose a drink">
          {FLAVORS.map((f, i) => (
            <button
              key={f.id}
              type="button"
              role="tab"
              aria-selected={i === active}
              aria-label={f.name}
              onClick={() => goTo(i)}
              className={cn(
                "grid h-12 w-12 place-items-center rounded-full border-2 bg-cream/10 p-1.5 backdrop-blur-md transition-all duration-300 md:h-14 md:w-14",
                i === active ? "scale-110 border-lime bg-cream/25" : "border-cream/30 hover:border-cream",
              )}
            >
              <img src={f.icon} alt="" className="h-full w-full object-contain" loading="lazy" />
            </button>
          ))}
        </div>

        {/* cup */}
        <div className="absolute inset-0 flex items-center justify-center [perspective:1200px]">
          {FLAVORS.map((f, i) => (
            <img
              key={f.id}
              data-cup
              src={f.cup}
              alt={f.name}
              loading="lazy"
              className="drop-cup absolute h-[44vh] w-auto translate-y-[4vh] md:h-[58vh]"
              style={{ opacity: i === 0 ? 1 : 0, visibility: i === 0 ? "visible" : "hidden" }}
            />
          ))}
        </div>

        {/* script name over the cup */}
        <div className="pointer-events-none absolute inset-x-0 top-[58%] flex justify-center md:top-[60%]">
          {FLAVORS.map((f, i) => (
            <span
              key={f.id}
              data-copy={i}
              className="script absolute -rotate-[7deg] text-[19vw] text-cream md:text-[9vw]"
              style={{ opacity: i === 0 ? 1 : 0, visibility: i === 0 ? "visible" : "hidden" }}
            >
              {f.name.toLowerCase()}
            </span>
          ))}
        </div>

        {/* bottom bar */}
        <div className="absolute inset-x-0 bottom-0 grid gap-4 px-5 pb-8 md:grid-cols-3 md:items-end md:px-10 md:pb-10">
          <div className="relative min-h-[3.5rem]">
            {FLAVORS.map((f, i) => (
              <p
                key={f.id}
                data-copy={i}
                className="absolute bottom-0 max-w-xs text-sm leading-relaxed text-cream/85"
                style={{ opacity: i === 0 ? 1 : 0, visibility: i === 0 ? "visible" : "hidden" }}
              >
                {f.line}
              </p>
            ))}
          </div>
          <p className="label-mono hidden text-center md:block">
            <span className="rounded-full border border-cream/40 px-4 py-2">
              {current.price} — {current.size}
            </span>
          </p>
          <div className="flex items-center justify-between gap-4 md:justify-end">
            <span className="label-mono md:hidden">
              {current.price} — {current.size}
            </span>
            <Pill
              size="lg"
              onClick={openMenu}>
              Full menu
            </Pill>
          </div>
        </div>
      </div>
    </section>
  );
}
