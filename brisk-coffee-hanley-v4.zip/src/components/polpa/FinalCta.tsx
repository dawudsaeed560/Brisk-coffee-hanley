import { ORDER_URL, PERKS, SAMPLE_AUTHOR, SHOP } from "./data";
import { GoogleRating } from "./Perks";
import { useOpenMenu } from "./MenuDialog";
import { Pill } from "./Pill";
import { SplitReveal } from "./SplitReveal";
import { useTransitionNavigate } from "./PageTransition";

export function Footer() {
  return (
    <footer className="label-mono flex flex-col items-center justify-between gap-2 border-t border-cream/15 px-5 pb-24 pt-6 text-center md:pb-20 text-[0.625rem] text-cream/60 md:flex-row md:px-10">
      <span>Sample redesign by {SAMPLE_AUTHOR}</span>
      <span>
        {SHOP.address} · <a href={SHOP.phoneHref} className="hover:text-cream">{SHOP.phone}</a>
      </span>
      <span>Not the official Brisk website</span>
    </footer>
  );
}

export function FinalCta() {
  const go = useTransitionNavigate();
  const openMenu = useOpenMenu();
  return (
    <section className="relative flex min-h-screen flex-col bg-plum-glow text-cream">
      <div className="flex flex-1 flex-col items-center justify-center px-5 py-32 text-center">
        <p className="label-mono mb-8 text-cream/60">(05) Last orders</p>
        <SplitReveal
          as="h2"
          text={"GREAT COFFEE\nSTARTS HERE."}
          stagger={0.03}
          className="headline text-[17vw] md:text-[11vw]"
        />
        <p className="script -mt-[2vw] -rotate-[5deg] text-[13vw] text-lime md:text-[7vw]">see you soon</p>
        <div className="mt-12 flex flex-wrap items-center justify-center gap-6">
          <Pill size="lg" href={ORDER_URL} external ariaLabel="Order online (opens Brisk's ordering page)">
            Order online ↗
          </Pill>
          <Pill size="lg" variant="cream" onClick={openMenu}>
            View menu
          </Pill>
          <Pill size="lg" variant="cream" onClick={() => go("/visit")}>
            Visit today →
          </Pill>
        </div>
        <ul className="label-mono mt-14 flex max-w-3xl flex-wrap justify-center gap-x-6 gap-y-3 text-cream/75">
          {PERKS.map((p) => (
            <li key={p.id}>
              <span className="text-lime">{p.big}</span> {p.title}
            </li>
          ))}
        </ul>
        <GoogleRating className="mt-6 text-cream/75" />
      </div>
      <Footer />
    </section>
  );
}
