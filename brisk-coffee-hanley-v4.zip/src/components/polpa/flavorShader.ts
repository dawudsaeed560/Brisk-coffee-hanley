import { Mesh, Program, Renderer, Triangle, Vec2 } from "ogl";
import { ensureGsap } from "./motion";
import type { RGB, ShaderPalette } from "./data";

const vertex = /* glsl */ `
attribute vec2 uv;
attribute vec2 position;
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = vec4(position, 0.0, 1.0);
}
`;

const fragment = /* glsl */ `
precision highp float;
uniform float uTime;
uniform vec2 uRes;
uniform vec2 uMouse;
uniform vec3 uA;
uniform vec3 uB;
uniform vec3 uC;
varying vec2 vUv;

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float noise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
             mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);
}
float fbm(vec2 p) {
  float v = 0.0;
  float a = 0.5;
  mat2 m = mat2(1.6, 1.2, -1.2, 1.6);
  for (int i = 0; i < 5; i++) { v += a * noise(p); p = m * p; a *= 0.5; }
  return v;
}

void main() {
  vec2 uv = vUv;
  vec2 p = (uv - 0.5) * vec2(uRes.x / uRes.y, 1.0) * 2.4;
  float t = uTime * 0.07;
  vec2 m = (uMouse - 0.5) * 0.8;
  vec2 q = vec2(fbm(p + t), fbm(p + vec2(5.2, 1.3) - t));
  vec2 r = vec2(fbm(p + 3.0 * q + vec2(1.7, 9.2) + t * 1.4 + m),
                fbm(p + 3.0 * q + vec2(8.3, 2.8) - t));
  float f = fbm(p + 3.0 * r);

  vec3 col = mix(uA, uB, clamp(f * f * 2.4, 0.0, 1.0));
  col = mix(col, uA, clamp(length(q) * 0.45, 0.0, 1.0) * 0.6);
  col += uC * pow(clamp(f * 1.15, 0.0, 1.0), 4.0) * 0.9;

  float vig = smoothstep(1.15, 0.25, length(uv - 0.5) * 1.35);
  col *= mix(0.55, 1.0, vig);
  col += (hash(uv * uRes + uTime) - 0.5) * 0.035;
  gl_FragColor = vec4(col, 1.0);
}
`;

export interface FlavorShader {
  setRunning(v: boolean): void;
  setColors(p: ShaderPalette): void;
  destroy(): void;
}

/** Smoky fluid background. Renders at half resolution, only while running. */
export function createFlavorShader(
  host: HTMLElement,
  initial: ShaderPalette,
  reduced: boolean,
): FlavorShader | null {
  let renderer: Renderer;
  try {
    renderer = new Renderer({
      dpr: Math.min(window.devicePixelRatio || 1, 2) * 0.5,
      antialias: false,
      powerPreference: "high-performance",
    });
  } catch {
    return null;
  }
  const gl = renderer.gl;
  const canvas = gl.canvas as HTMLCanvasElement;
  canvas.setAttribute("aria-hidden", "true");
  canvas.style.position = "absolute";
  canvas.style.inset = "0";
  host.appendChild(canvas);

  const a: RGB = [...initial.a];
  const b: RGB = [...initial.b];
  const c: RGB = [...initial.c];
  const res = new Vec2(1, 1);
  const mouse = new Vec2(0.5, 0.5);
  const mouseTarget = { x: 0.5, y: 0.5 };
  const program = new Program(gl, {
    vertex,
    fragment,
    uniforms: {
      uTime: { value: 0 },
      uRes: { value: res },
      uMouse: { value: mouse },
      uA: { value: a },
      uB: { value: b },
      uC: { value: c },
    },
  });
  const mesh = new Mesh(gl, { geometry: new Triangle(gl), program });

  const t0 = performance.now();
  const draw = (now: number) => {
    program.uniforms["uTime"]!.value = reduced ? 12 : (now - t0) / 1000;
    mouse.x += (mouseTarget.x - mouse.x) * 0.04;
    mouse.y += (mouseTarget.y - mouse.y) * 0.04;
    renderer.render({ scene: mesh });
  };

  const resize = () => {
    const r = host.getBoundingClientRect();
    renderer.setSize(Math.max(1, r.width), Math.max(1, r.height));
    canvas.style.width = "100%";
    canvas.style.height = "100%";
    res.set(r.width, r.height);
    draw(performance.now());
  };
  const ro = new ResizeObserver(resize);
  ro.observe(host);
  resize();

  let running = false;
  let raf = 0;
  const loop = (now: number) => {
    draw(now);
    if (running) raf = requestAnimationFrame(loop);
  };

  const onMove = (e: PointerEvent) => {
    mouseTarget.x = e.clientX / window.innerWidth;
    mouseTarget.y = 1 - e.clientY / window.innerHeight;
  };
  window.addEventListener("pointermove", onMove, { passive: true });

  const { gsap } = ensureGsap();
  let colorTween: gsap.core.Tween | null = null;

  return {
    setRunning(v) {
      const next = v && !reduced && !document.hidden;
      if (next === running) return;
      running = next;
      cancelAnimationFrame(raf);
      if (running) raf = requestAnimationFrame(loop);
    },
    setColors(p) {
      colorTween?.kill();
      const from = { a: [...a], b: [...b], c: [...c] };
      const apply = (k: number) => {
        for (let i = 0; i < 3; i++) {
          a[i] = from.a[i]! + (p.a[i]! - from.a[i]!) * k;
          b[i] = from.b[i]! + (p.b[i]! - from.b[i]!) * k;
          c[i] = from.c[i]! + (p.c[i]! - from.c[i]!) * k;
        }
      };
      if (reduced) {
        apply(1);
        draw(performance.now());
        return;
      }
      const s = { k: 0 };
      colorTween = gsap.to(s, {
        k: 1,
        duration: 1.2,
        ease: "power2.inOut",
        onUpdate: () => {
          apply(s.k);
          if (!running) draw(performance.now());
        },
      });
    },
    destroy() {
      running = false;
      cancelAnimationFrame(raf);
      colorTween?.kill();
      ro.disconnect();
      window.removeEventListener("pointermove", onMove);
      gl.getExtension("WEBGL_lose_context")?.loseContext();
      canvas.remove();
    },
  };
}
