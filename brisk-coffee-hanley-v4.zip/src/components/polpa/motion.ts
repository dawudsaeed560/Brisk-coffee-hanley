import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Lenis from "lenis";

let registered = false;

export function ensureGsap() {
  if (!registered && typeof window !== "undefined") {
    gsap.registerPlugin(ScrollTrigger);
    registered = true;
  }
  return { gsap, ScrollTrigger };
}

export function prefersReducedMotion(): boolean {
  return (
    typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches
  );
}

export function hasFinePointer(): boolean {
  return typeof window !== "undefined" && window.matchMedia("(pointer: fine)").matches;
}

let lenis: Lenis | null = null;

/** Starts Lenis and drives it from the GSAP ticker so ScrollTrigger stays in sync. */
export function startSmoothScroll(): () => void {
  ensureGsap();
  if (prefersReducedMotion()) return () => {};
  const instance = new Lenis({ lerp: 0.1 });
  lenis = instance;
  instance.on("scroll", ScrollTrigger.update);
  const tick = (time: number) => instance.raf(time * 1000);
  gsap.ticker.add(tick);
  gsap.ticker.lagSmoothing(0);
  return () => {
    gsap.ticker.remove(tick);
    instance.destroy();
    if (lenis === instance) lenis = null;
  };
}

const easeInOutCubic = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

function resolveY(target: number | string | HTMLElement, offset: number): number | null {
  if (typeof target === "number") return target + offset;
  const el = typeof target === "string" ? document.querySelector(target) : target;
  if (!el) return null;
  return el.getBoundingClientRect().top + window.scrollY + offset;
}

function scrollInstant(y: number) {
  if (lenis) lenis.scrollTo(y, { immediate: true, force: true });
  else window.scrollTo(0, y);
  ScrollTrigger.update();
}

let veil: HTMLDivElement | null = null;
let veilBusy = false;

function getVeil(): HTMLDivElement {
  if (!veil || !veil.isConnected) {
    veil = document.createElement("div");
    veil.className = "scroll-veil";
    veil.setAttribute("aria-hidden", "true");
    document.body.appendChild(veil);
  }
  return veil;
}

/** Long jumps fade a quick veil, cut to the target and fade back, instead of racing through every pinned scene. */
function veilJump(y: number) {
  if (veilBusy) return;
  veilBusy = true;
  const el = getVeil();
  gsap
    .timeline({ onComplete: () => void (veilBusy = false) })
    .to(el, { autoAlpha: 1, duration: 0.3, ease: "power2.inOut" })
    .add(() => scrollInstant(y))
    .to(el, { autoAlpha: 0, duration: 0.5, delay: 0.18, ease: "power2.out" });
}

/** Short hops glide with an eased, distance-scaled duration; long jumps use the veil. */
export function smoothScrollTo(target: number | string | HTMLElement, offset = 0) {
  if (typeof window === "undefined") return;
  ensureGsap();
  const y = resolveY(target, offset);
  if (y === null) return;
  const distance = Math.abs(y - window.scrollY);
  if (distance < 2) return;
  if (prefersReducedMotion()) {
    scrollInstant(y);
    return;
  }
  const vh = window.innerHeight || 800;
  if (distance > vh * 1.25) {
    veilJump(y);
    return;
  }
  const duration = Math.min(1.1, 0.55 + (distance / vh) * 0.45);
  if (lenis) lenis.scrollTo(y, { duration, easing: easeInOutCubic, lock: true });
  else window.scrollTo({ top: y, behavior: "smooth" });
}

export function jumpToTop() {
  lenis?.scrollTo(0, { immediate: true, force: true });
  window.scrollTo(0, 0);
}

export function lockScroll(lock: boolean) {
  if (lenis) {
    if (lock) lenis.stop();
    else lenis.start();
  }
  document.documentElement.style.overflow = lock ? "hidden" : "";
}

/** The intro only plays once per visit. */
export const session = { introPlayed: false };
