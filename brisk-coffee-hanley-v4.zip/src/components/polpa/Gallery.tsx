import { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";
import { GALLERY } from "./data";
import { ensureGsap, prefersReducedMotion } from "./motion";
import { SplitReveal } from "./SplitReveal";

const TILE = {
  wide: { item: "md:col-span-8", frame: "aspect-[16/10] md:aspect-[2/1]" },
  square: { item: "md:col-span-4", frame: "aspect-[4/5] md:aspect-[24/25]" },
  tall: { item: "md:col-span-3", frame: "aspect-[4/5] md:aspect-[3/4]" },
} as const;

export function Gallery() {
  const ref = useRef<HTMLElement>(null);
  useEffect(() => {
    if (!ref.current || prefersReducedMotion()) return;
    const { gsap } = ensureGsap();
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>("[data-gallery]").forEach((el, i) => {
        gsap.fromTo(
          el,
          { autoAlpha: 0, y: 60 },
          {
            autoAlpha: 1,
            y: 0,
            duration: 1.1,
            delay: (i % 4) * 0.06,
            ease: "expo.out",
            scrollTrigger: { trigger: el, start: "top 90%", once: true },
          },
        );
      });
    }, ref);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={ref} id="gallery" aria-label="Gallery" className="bg-cream px-5 py-28 text-ink md:px-10">
      <div className="mx-auto max-w-6xl">
        <p className="label-mono mb-6">(03) Inside Brisk Hanley</p>
        <SplitReveal as="h2" text="THE GALLERY" className="headline text-[16vw] md:text-[8vw]" />
        <p className="script -mt-2 -rotate-[4deg] text-[10vw] text-tomato md:text-[4.5vw]">pull up a chair</p>
        <ul className="mt-14 grid items-start gap-6 md:grid-cols-12">
          {GALLERY.map((g, i) => {
            const tile = TILE[g.layout];
            return (
              <li
                key={g.src}
                data-gallery
                className={cn("gallery-item", tile.item, g.layout === "tall" && i % 2 === 1 && "md:mt-12")}
              >
                <div className="overflow-hidden rounded-[1.25rem] shadow-pill">
                  <img
                    src={g.src}
                    alt={g.alt}
                    loading="lazy"
                    decoding="async"
                    width={g.width}
                    height={g.height}
                    className={cn("gallery-image h-full w-full object-cover", tile.frame)}
                  />
                </div>
                <p className="label-mono mt-4">
                  0{i + 1} — {g.caption}
                </p>
              </li>
            );
          })}
        </ul>
        <p className="label-mono mt-12 opacity-60">Photos from Brisk’s own website, used for this sample.</p>
      </div>
    </section>
  );
}
