import { cn } from "@/lib/utils";
import { GOOGLE_RATING, ORDER_URL, PERKS } from "./data";
import { Pill } from "./Pill";

/** Google rating for the Hanley shop, linking to its Google listing. */
export function GoogleRating({ className }: { className?: string }) {
  return (
    <a
      href={GOOGLE_RATING.url}
      target="_blank"
      rel="noopener noreferrer"
      className={cn("label-mono inline-flex items-center gap-2 hover:opacity-70", className)}
      aria-label={`Rated ${GOOGLE_RATING.score} out of 5 from ${GOOGLE_RATING.count} Google reviews`}
    >
      <span aria-hidden>★</span> {GOOGLE_RATING.score} on Google · {GOOGLE_RATING.count} reviews
    </a>
  );
}

/** Student / NHS discounts, loyalty card and halal options: real reasons to choose Brisk. */
export function Perks({ tone = "dark" }: { tone?: "dark" | "light" }) {
  const dark = tone === "dark";
  return (
    <section id="perks" aria-label="Discounts, loyalty card and halal options" className="mt-24">
      <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <p className={cn("label-mono mb-4", dark ? "text-lime" : "text-tomato")}>(02) Why locals choose Brisk</p>
          <h2 className="headline text-6xl md:text-7xl">THE GOOD STUFF</h2>
        </div>
        <GoogleRating className={dark ? "text-cream/80" : "text-ink/70"} />
      </div>
      <ul className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {PERKS.map((p) => (
          <li
            key={p.id}
            className={cn(
              "flex flex-col rounded-[1.25rem] border p-6",
              dark ? "border-cream/15 bg-cream/5" : "border-ink/15 bg-ink/5",
            )}
          >
            <span className={cn("headline text-6xl", dark ? "text-lime" : "text-tomato")}>{p.big}</span>
            <span className="label-mono mt-2">{p.title}</span>
            <p className={cn("mt-4 text-sm leading-relaxed", dark ? "text-cream/75" : "text-ink/70")}>{p.line}</p>
          </li>
        ))}
      </ul>
      <div className="mt-10">
        <Pill size="lg" href={ORDER_URL} external ariaLabel="Order online (opens Brisk's ordering page)">
          Order online ↗
        </Pill>
      </div>
    </section>
  );
}
