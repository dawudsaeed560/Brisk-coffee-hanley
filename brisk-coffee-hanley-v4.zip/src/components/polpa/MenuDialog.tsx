import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { MENU, ORDER_URL } from "./data";
import { Pill } from "./Pill";
import { lockScroll } from "./motion";

const MenuContext = createContext<() => void>(() => {});

/** Opens the full Brisk menu pop-up from anywhere on the site. */
export const useOpenMenu = () => useContext(MenuContext);

const CATEGORIES = ["Coffee", "Food"] as const;

export function MenuDialogProvider({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const openMenu = useCallback(() => setOpen(true), []);

  useEffect(() => {
    if (!open) return;
    lockScroll(true);
    return () => lockScroll(false);
  }, [open]);

  return (
    <MenuContext.Provider value={openMenu}>
      {children}
      <DialogPrimitive.Root open={open} onOpenChange={setOpen}>
        <DialogPrimitive.Portal>
          <DialogPrimitive.Overlay className="fixed inset-0 z-[120] bg-ink/80 backdrop-blur-sm data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0" />
          <DialogPrimitive.Content
            data-lenis-prevent
            className="menu-scroll fixed inset-2 z-[121] overflow-y-auto rounded-[1.25rem] bg-cream text-ink shadow-pill duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=open]:slide-in-from-bottom-8 md:inset-6"
          >
            <div className="sticky top-0 z-10 flex items-center justify-between bg-cream/90 px-5 py-4 backdrop-blur-md md:px-10">
              <span className="label-mono">Brisk Coffee Hanley — Menu</span>
              <DialogPrimitive.Close className="label-mono rounded-full bg-ink px-4 py-2 text-cream transition-colors hover:bg-tomato focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                Close ✕
              </DialogPrimitive.Close>
            </div>
            <div className="px-5 pb-16 pt-8 md:px-10">
              <DialogPrimitive.Title className="headline text-[18vw] md:text-[9vw]">The menu</DialogPrimitive.Title>
              <p className="script -mt-2 -rotate-[4deg] text-[10vw] text-tomato md:text-[4.5vw]">made fresh daily</p>
              <DialogPrimitive.Description className="label-mono mt-10 max-w-md leading-relaxed text-ink/70">
                Speciality coffee, breakfast, brunch and bakes. Halal turkey bacon, beef sausage and chicken paninis. 25% off for students, 10% off for NHS staff. Vegan, vegetarian and gluten-free options and dairy-free milk: just ask.
              </DialogPrimitive.Description>

              {CATEGORIES.map((cat, ci) => (
                <section key={cat} className="mt-14" aria-label={cat}>
                  <p className="label-mono mb-4 text-ink/60">
                    (0{ci + 1}) {cat}
                  </p>
                  <ul className="grid border-t border-ink/20 sm:grid-cols-2 lg:grid-cols-4">
                    {MENU.filter((m) => m.category === cat).map((m) => (
                      <li key={m.name} className="menu-card group flex items-center gap-4 py-6 sm:pr-6">
                        <img
                          src={m.image}
                          alt={m.name}
                          loading="lazy"
                          className="menu-card-image drop-fruit h-24 w-24 shrink-0 object-contain md:h-28 md:w-28"
                        />
                        <div className="min-w-0">
                          <h3 className="headline text-4xl">{m.name}</h3>
                          <p className="mt-1 text-xs leading-relaxed text-ink/70">{m.line}</p>
                          <p className="label-mono mt-2">
                            <span className="rounded-full border border-ink/40 px-3 py-1">{m.price}</span>
                          </p>
                        </div>
                      </li>
                    ))}
                  </ul>
                </section>
              ))}
              <div className="mt-12 flex flex-col items-start gap-6 md:flex-row md:items-center md:justify-between">
                <p className="label-mono text-ink/50">Prices from Brisk's order page (Nov 2026) and may change. Full menu online.</p>
                <Pill size="md" variant="ink" href={ORDER_URL} external ariaLabel="Order online (opens Brisk's ordering page)">
                  Order online ↗
                </Pill>
              </div>
            </div>
          </DialogPrimitive.Content>
        </DialogPrimitive.Portal>
      </DialogPrimitive.Root>
    </MenuContext.Provider>
  );
}
