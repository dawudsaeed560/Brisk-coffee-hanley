import { useEffect, useRef } from "react";
import { useOpenMenu } from "./MenuDialog";
import { ensureGsap, smoothScrollTo } from "./motion";
import { useTransitionNavigate } from "./PageTransition";
import { Pill } from "./Pill";
import { ORDER_URL } from "./data";

const LINKS = [
  { label: "About", target: "#manifesto" },
  { label: "Menu", target: "#menu" },
] as const;

export function Nav() {
  const barRef = useRef<HTMLDivElement>(null);
  const openMenu = useOpenMenu();
  const go = useTransitionNavigate();

  useEffect(() => {
    const { ScrollTrigger } = ensureGsap();
    const st = ScrollTrigger.create({
      start: 0,
      end: "max",
      onUpdate: (self) => {
        if (barRef.current) barRef.current.style.transform = `scaleX(${self.progress})`;
      },
    });
    return () => st.kill();
  }, []);

  return (
    <>
      <div
        ref={barRef}
        aria-hidden
        className="fixed inset-x-0 top-0 z-[60] h-[3px] origin-left scale-x-0 bg-progress"
      />
      {/* Blended layer: stays readable on every colour world */}
      <header className="pointer-events-none fixed inset-x-0 top-0 z-50 text-cream mix-blend-difference">
        <nav className="flex items-center justify-between px-5 py-5 md:px-10" aria-label="Main">
          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              smoothScrollTo(0);
            }}
            aria-label="Brisk Coffee Hanley — back to top"
            className="pointer-events-auto flex items-center gap-2 font-display text-2xl uppercase tracking-wide md:text-3xl"
          >
            BRISK <span aria-hidden className="text-lg">●</span>
          </a>
          <ul className="label-mono pointer-events-auto absolute left-1/2 hidden -translate-x-1/2 gap-10 md:flex">
            {LINKS.map((l) => (
              <li key={l.label}>
                <a
                  href={l.target}
                  onClick={(e) => {
                    e.preventDefault();
                    smoothScrollTo(l.target);
                  }}
                  className="transition-opacity hover:opacity-60"
                >
                  {l.label}
                </a>
              </li>
            ))}
            <li>
              <a
                href="/visit"
                onClick={(e) => {
                  e.preventDefault();
                  go("/visit");
                }}
                className="transition-opacity hover:opacity-60"
              >
                Visit
              </a>
            </li>
          </ul>
          <span className="w-28" />
        </nav>
      </header>
      <div className="fixed right-5 top-4 z-50 flex gap-2 md:right-10 md:gap-3">
        <Pill size="sm" variant="cream" href={ORDER_URL} external ariaLabel="Order online (opens Brisk's ordering page)">
          Order ↗
        </Pill>
        <Pill size="sm" onClick={openMenu}>
          View menu
        </Pill>
      </div>
    </>
  );
}
