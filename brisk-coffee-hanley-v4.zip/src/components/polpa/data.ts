import shopfront from "@/assets/gallery/hanley-shopfront.webp.asset.json";
import latteInHand from "@/assets/gallery/hanley-latte-in-hand.webp.asset.json";
import windowLatte from "@/assets/gallery/hanley-window-latte.webp.asset.json";
import pastries from "@/assets/gallery/hanley-pastries.webp.asset.json";
import traybakes from "@/assets/gallery/hanley-traybakes.webp.asset.json";
import bagel from "@/assets/gallery/hanley-bagel.webp.asset.json";

/** Brisk content and image registry. Prices, perks, rating and reviews are taken from briskcoffee.co and Google (checked Nov 2026). */
export type RGB = [number, number, number];
export interface ShaderPalette { a: RGB; b: RGB; c: RGB; }
export interface Flavor { id: string; name: string; cup: string; icon: string; line: string; price: string; size: string; shader: ShaderPalette; }
const image = (name: string) => `/images/coffee/${name}.webp`;
export const CUPS = { mango: image("cup-takeaway"), blueberry: image("cup-flat-white"), strawberry: image("cup-cappuccino"), kiwi: image("cup-iced-coffee") } as const;
export const FRUIT = {
  croissant: { src: image("croissant"), aspect: 1.3, shape: "banana" },
  bean: { src: image("bean"), aspect: 0.85, shape: "circle" },
  cookie: { src: image("cookie"), aspect: 1, shape: "circle" },
  bun: { src: image("cinnamon-bun"), aspect: 1, shape: "round" },
  espresso: { src: image("espresso"), aspect: 1.1, shape: "round" },
} as const;
export type FruitName = keyof typeof FRUIT;
export const FLAVORS: Flavor[] = [
 { id: "flat-white", name: "Flat White", cup: CUPS.blueberry, icon: CUPS.blueberry, line: "A double shot, silky microfoam. Small cup. Big personality.", price: "£3.70", size: "8OZ · SPECIALITY COFFEE", shader: { a: [0.12,0.055,0.025], b: [0.36,0.23,0.13], c: [0.78,0.61,0.37] } },
 { id: "latte", name: "Latte", cup: image("cup-latte"), icon: image("cup-latte"), line: "Smooth espresso meets steamed milk. Your daily little luxury.", price: "£3.95", size: "16OZ · SPECIALITY COFFEE", shader: { a: [0.20,0.10,0.05], b: [0.49,0.32,0.18], c: [0.85,0.76,0.64] } },
 { id: "cappuccino", name: "Cappuccino", cup: CUPS.strawberry, icon: CUPS.strawberry, line: "Rich espresso, velvety foam, a little cocoa. The classic, done properly.", price: "£3.95", size: "16OZ · SPECIALITY COFFEE", shader: { a: [0.10,0.07,0.05], b: [0.30,0.17,0.10], c: [0.72,0.52,0.32] } },
 { id: "iced-latte", name: "Iced Latte", cup: CUPS.kiwi, icon: CUPS.kiwi, line: "Freshly pulled, poured over ice. For when your day needs a cool head.", price: "£3.95", size: "SERVED OVER ICE", shader: { a: [0.07,0.07,0.07], b: [0.23,0.14,0.09], c: [0.65,0.48,0.30] } },
];
export const MENU = [
 { name: "Espresso", price: "£2.40", image: image("espresso"), category: "Coffee", line: "Short, rich and full of character." },
 { name: "Flat White", price: "£3.70", image: CUPS.blueberry, category: "Coffee", line: "Double espresso. Silky microfoam." },
 { name: "Cappuccino", price: "£3.95", image: CUPS.strawberry, category: "Coffee", line: "Velvety foam and a dusting of cocoa." },
 { name: "Latte", price: "£3.95", image: image("cup-latte"), category: "Coffee", line: "Espresso, softened with steamed milk." },
 { name: "Mocha", price: "£3.90", image: image("cup-mocha"), category: "Coffee", line: "Coffee and chocolate. Better together." },
 { name: "Americano", price: "£3.40", image: image("americano"), category: "Coffee", line: "Bold espresso, a little more room." },
 { name: "Iced Latte", price: "£3.95", image: CUPS.kiwi, category: "Coffee", line: "Fresh espresso and cold milk over ice." },
 { name: "Hot Chocolate", price: "£4.00", image: image("hot-chocolate"), category: "Coffee", line: "Deep cocoa and pure comfort." },
 { name: "Breakfast Baps", price: "From £4.15", image: image("breakfast"), category: "Food", line: "Halal turkey bacon or beef sausage, add an egg." },
 { name: "Paninis", price: "From £4.95", image: image("brunch"), category: "Food", line: "Toasted to order, with halal chicken options." },
 { name: "Fresh Pastries", price: "From £2.45", image: image("croissant"), category: "Food", line: "Golden, flaky, freshly baked." },
 { name: "Cakes", price: "From £2.80", image: image("cake"), category: "Food", line: "Always room for a slice." },
] as const;
export const SHOP = { name: "Brisk Coffee Hanley", address: "1–3 Lamb Street, Hanley, Stoke-on-Trent, ST1 1PF", phone: "01782 698787", phoneHref: "tel:+441782698787", email: "briskcoffeeco@gmail.com", directions: "https://www.google.com/maps/dir/?api=1&destination=Brisk+Coffee+Co+1-3+Lamb+Street+Hanley+ST1+1PF", map: "https://maps.google.com/maps?q=Brisk%20Coffee%20Co%201-3%20Lamb%20Street%20Hanley%20ST1%201PF&t=&z=16&ie=UTF8&iwloc=&output=embed" };
export const HOURS = [ { days: "Monday – Saturday", hours: "8:00am – 5:30pm", opens: "08:00", closes: "17:30" }, { days: "Sunday", hours: "9:00am – 4:00pm", opens: "09:00", closes: "16:00" } ];
export const MARQUEE_WORDS = ["Coffee", "Pastries", "Breakfast", "Brunch", "Hanley"];
export const STATEMENT = "GOOD COFFEE. GREAT FOOD. YOUR KIND OF PLACE — RIGHT HERE IN HANLEY.";
export interface Sticker { label: string; variant: "ink" | "tomato" | "cream" | "navy"; angle: number; position: string; }
export const STICKERS: Sticker[] = [
 { label: "Speciality coffee", variant: "ink", angle: -12, position: "left-[6%] top-[22%] md:left-[9%] md:top-[26%]" },
 { label: "Freshly prepared food", variant: "cream", angle: 6, position: "left-[3%] top-[62%] md:left-[4%] md:top-[56%]" },
 { label: "Local ingredients", variant: "tomato", angle: 5, position: "left-[10%] bottom-[16%] md:left-[22%] md:bottom-[16%]" },
 { label: "Friendly service", variant: "tomato", angle: 8, position: "right-[5%] top-[36%] md:right-[9%] md:top-[30%]" },
 { label: "Free WiFi", variant: "ink", angle: -9, position: "right-[8%] top-[64%] md:right-[5%] md:top-[58%]" },
 { label: "Dog friendly", variant: "navy", angle: -7, position: "right-[12%] bottom-[9%] md:right-[18%] md:bottom-[18%]" },
];
export interface PlayFruit { fruit: FruitName; scale: number; }
export const PLAY_FRUITS: PlayFruit[] = [
 {fruit:"croissant",scale:1},{fruit:"bean",scale:1.25},{fruit:"cookie",scale:1.55},{fruit:"bun",scale:0.85},{fruit:"espresso",scale:1},{fruit:"croissant",scale:0.85},{fruit:"cookie",scale:1.3},{fruit:"bean",scale:1.05},{fruit:"bun",scale:0.7},{fruit:"croissant",scale:1.1},{fruit:"espresso",scale:0.8},{fruit:"bun",scale:0.75},
];
export const SMALL_SCREEN_FRUIT = 7;
/** Real photos from Brisk Coffee Hanley (briskcoffee.co). `layout` sets the tile shape in the gallery grid. */
export const GALLERY = [
 { src: shopfront.url, width: 1600, height: 900, layout: "wide", alt: "Brisk Coffee Co on the corner of Lamb Street, Hanley, with tables outside", caption: "Find us on Lamb Street" },
 { src: latteInHand.url, width: 1000, height: 1000, layout: "square", alt: "A latte with a tulip in a cream Brisk cup, held over the counter in Hanley", caption: "Poured with care" },
 { src: windowLatte.url, width: 800, height: 1067, layout: "tall", alt: "A latte and a slice of cake at the window table in Hanley", caption: "Window seat, slice of cake" },
 { src: pastries.url, width: 800, height: 1067, layout: "tall", alt: "Fresh Danish pastries and cinnamon swirls on a tray at Brisk", caption: "Baked fresh every morning" },
 { src: traybakes.url, width: 800, height: 1067, layout: "tall", alt: "Brownies, flapjacks and traybakes on the counter at Brisk Hanley", caption: "Traybakes on the counter" },
 { src: bagel.url, width: 800, height: 1067, layout: "tall", alt: "A smoked salmon and cream cheese bagel served at Brisk Hanley", caption: "Brunch, sorted" },
] as const;
export const HERO = {
  kicker: "Lamb Street · Hanley",
  title: "HANLEY'S FAVOURITE\nINDEPENDENT\nCOFFEE SHOP",
  sub: "Speciality coffee, freshly baked pastries, breakfast and brunch served daily in the heart of Hanley.",
};
export const ABOUT_LINE = "Brisk is an independent speciality coffee shop: quality coffee, delicious food and a welcome that makes you want to stay for another.";
/**
 * Hanley reviews copied word for word from the briskcoffee.co home page (checked Nov 2026).
 * Their site doesn't say which platform each came from, so the label names briskcoffee.co.
 * Private people: first name and initial only.
 */
export const TESTIMONIALS = [
 { quote: "Had the salted cinnamon cloud latte and it was amazing. Nice fluffy head and great tasting coffee.", name: "Mark B.", detail: "Hanley · review quoted on briskcoffee.co" },
 { quote: "Great relaxed atmosphere. Service is excellent staff are super friendly and helpful.", name: "Michael C.", detail: "Hanley · review quoted on briskcoffee.co" },
];

/** Who made this sample redesign; shown in the footer. */
export const SAMPLE_AUTHOR = "Dawud Saeed";

/** Brisk's existing online ordering page (order ahead and collect). */
export const ORDER_URL = "https://briskcoffee.co/order-online/";

/** Google rating for the Hanley shop, read from its Google Maps listing. Update when it changes. */
export const GOOGLE_RATING = {
  score: "4.2",
  count: 593,
  checked: "Nov 2026",
  url: "https://www.google.com/maps/search/?api=1&query=Brisk+Coffee+Co+Hanley+1-3+Lamb+Street+ST1+1PF",
};

/** Reasons to choose Brisk, as stated on briskcoffee.co. */
export const PERKS = [
 { id: "students", big: "25%", title: "off for students", line: "All day, every day. Just show your student ID." },
 { id: "nhs", big: "10%", title: "off for NHS staff", line: "Always. Fuelling the heroes who fuel our nation." },
 { id: "loyalty", big: "10", title: "stamps = free coffee", line: "Collect 10 stamps and your next coffee's on us. Ask for a card at the till." },
 { id: "halal", big: "Halal", title: "breakfast & paninis", line: "Halal turkey bacon, beef sausage and chicken paninis on the menu." },
] as const;

/** Which flavor scene is showing for a given scroll progress (0..1) through the flavors section. */
export function flavorIndexFromProgress(progress: number, count: number): number {
  if (count <= 0) return 0;
  const p = Math.min(Math.max(progress, 0), 1);
  return Math.min(count - 1, Math.floor(p * count));
}

/** Scroll progress (0..1) that lands in the middle of a flavor's scene. */
export function progressForFlavor(index: number, count: number): number {
  if (count <= 0) return 0;
  const i = Math.min(Math.max(index, 0), count - 1);
  return (i + 0.5) / count;
}

/** Small deterministic pseudo-random so server and client render the same decorations. */
export function seeded(i: number): number {
  // integer hash (no Math.sin) so server and browser agree exactly
  let h = (i + 1) * 2654435761;
  h = Math.imul(h ^ (h >>> 16), 2246822507);
  h = Math.imul(h ^ (h >>> 13), 3266489909);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}
