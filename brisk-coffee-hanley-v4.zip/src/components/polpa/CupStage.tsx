import { useEffect, useRef, type CSSProperties } from "react";
import { cn } from "@/lib/utils";
import { ABOUT_LINE, CUPS, HERO, MARQUEE_WORDS, ORDER_URL, STATEMENT, seeded } from "./data";
import { GoogleRating } from "./Perks";
import { useOpenMenu } from "./MenuDialog";
import { useTransitionNavigate } from "./PageTransition";
import { Pill } from "./Pill";
import { ensureGsap, prefersReducedMotion } from "./motion";
import { SplitReveal } from "./SplitReveal";

const FLOATERS = [
  {
    src: CUPS.blueberry,
    alt: "Flat white with latte art",
    pos: "left-[-6%] top-[14%] md:left-[8%] md:top-[12%]",
    size: "h-[28vh] md:h-[40vh]",
    rot: -14,
    depth: 1.3,
    layer: "z-[1]",
  },
  {
    src: CUPS.strawberry,
    alt: "Cappuccino",
    pos: "right-[-6%] top-[10%] md:right-[9%] md:top-[9%]",
    size: "h-[26vh] md:h-[36vh]",
    rot: 12,
    depth: 0.9,
    layer: "z-[1]",
  },
  {
    src: CUPS.kiwi,
    alt: "Iced coffee",
    pos: "right-[4%] bottom-[12%] md:right-[22%] md:bottom-[5%]",
    size: "h-[18vh] md:h-[22vh] blur-[2px]",
    rot: 22,
    depth: 0.5,
    layer: "z-[1]",
  },
];

function Star({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden className={cn("inline-block fill-mustard", className)}>
      <path d="M12 0C13 8 16 11 24 12C16 13 13 16 12 24C11 16 8 13 0 12C8 11 11 8 12 0Z" />
    </svg>
  );
}

function MarqueeRow({ words }: { words: string[] }) {
  const items = [...words, ...words, ...words];
  return (
    <>
      {items.map((w, i) => (
        <span key={i} className="flex items-center">
          <span className="px-[0.12em]">{w}</span>
          <Star className="mx-[0.12em] h-[0.42em] w-[0.42em]" />
        </span>
      ))}
    </>
  );
}

const BERRIES = Array.from({ length: 18 }, (_, i) => ({
  left: `${Math.round(seeded(i) * 100)}%`,
  size: 8 + Math.round(seeded(i + 40) * 12),
  dur: `${(6 + seeded(i + 80) * 6).toFixed(2)}s`,
  delay: `${(-seeded(i + 120) * 12).toFixed(2)}s`,
  drift: `${Math.round((seeded(i + 160) - 0.5) * 120)}px`,
}));

/**
 * Hero, flavor marquee and manifesto share one pinned hero cup that scrubs
 * (rotate / scale) as the sections change underneath it.
 */
export function CupStage({ introDone }: { introDone: boolean }) {
  const openMenu = useOpenMenu();
  const go = useTransitionNavigate();
  const stageRef = useRef<HTMLDivElement>(null);
  const heroContentRef = useRef<HTMLDivElement>(null);
  const wipeRef = useRef<HTMLDivElement>(null);
  const cupScrollRef = useRef<HTMLDivElement>(null);
  const cupEnterRef = useRef<HTMLDivElement>(null);
  const cupImgRef = useRef<HTMLImageElement>(null);
  const row1Ref = useRef<HTMLDivElement>(null);
  const row2Ref = useRef<HTMLDivElement>(null);
  const statementRef = useRef<HTMLElement>(null);
  const statementTextRef = useRef<HTMLParagraphElement>(null);
  const words = STATEMENT.split(" ");

  // Scroll scrubbing, parallax, bobbing
  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;
    const { gsap } = ensureGsap();
    const reduced = prefersReducedMotion();

    const ctx = gsap.context(() => {
      if (reduced) return;
      // Hero starts with the cup lowered so the headline reads; it rises to centre as you scroll.
      const heroDrop = () => window.innerHeight * (window.innerWidth >= 768 ? 0.2 : 0.05);
      gsap.set(cupScrollRef.current, { transformPerspective: 900, y: heroDrop });
      gsap.set(cupEnterRef.current, { autoAlpha: 0, yPercent: 50, scale: 0.6, rotation: -28 });
      gsap.set("[data-floater]", { autoAlpha: 0, scale: 0.4 });

      const tl = gsap.timeline({
        defaults: { ease: "none" },
        scrollTrigger: { trigger: stage, start: "top top", end: "bottom bottom", scrub: 0.8 },
      });
      tl.to(wipeRef.current, { clipPath: "circle(150% at 50% 55%)", duration: 1 }, 0)
        .to(cupScrollRef.current, { rotation: 10, scale: 0.84, y: 0, duration: 1 }, 0)
        .to(heroContentRef.current, { yPercent: -14, scale: 0.92, duration: 1 }, 0)
        .to(cupScrollRef.current, { rotation: -9, rotationY: 18, scale: 0.78, duration: 1 }, 1)
        .to(cupScrollRef.current, { rotation: 16, rotationY: -12, scale: 0.6, duration: 1.5 }, 2);

      gsap.fromTo(
        row1Ref.current,
        { xPercent: 0 },
        {
          xPercent: -33.333,
          ease: "none",
          scrollTrigger: { trigger: row1Ref.current, start: "top bottom", end: "bottom top", scrub: 0.6 },
        },
      );
      gsap.fromTo(
        row2Ref.current,
        { xPercent: -33.333 },
        {
          xPercent: 0,
          ease: "none",
          scrollTrigger: { trigger: row2Ref.current, start: "top bottom", end: "bottom top", scrub: 0.6 },
        },
      );

      gsap.fromTo(
        statementTextRef.current?.querySelectorAll("[data-word]") ?? [],
        { opacity: 0.12 },
        {
          opacity: 1,
          stagger: 0.1,
          ease: "none",
          scrollTrigger: {
            trigger: statementTextRef.current,
            start: "top 80%",
            end: "bottom 60%",
            scrub: true,
          },
        },
      );

      // bobbing
      gsap.utils.toArray<HTMLElement>("[data-bob]").forEach((el, i) => {
        gsap.to(el, {
          y: "+=18",
          rotation: i % 2 ? 3 : -3,
          duration: 2.4 + i * 0.45,
          ease: "sine.inOut",
          yoyo: true,
          repeat: -1,
        });
      });
    }, stage);

    // mouse parallax
    const movers = reduced
      ? []
      : Array.from(stage.querySelectorAll<HTMLElement>("[data-depth]")).map((el) => ({
          depth: Number(el.dataset["depth"] ?? 1),
          x: gsap.quickTo(el, "x", { duration: 1.2, ease: "power3.out" }),
          y: gsap.quickTo(el, "y", { duration: 1.2, ease: "power3.out" }),
        }));
    const onMove = (e: PointerEvent) => {
      const nx = e.clientX / window.innerWidth - 0.5;
      const ny = e.clientY / window.innerHeight - 0.5;
      for (const m of movers) {
        m.x(nx * 50 * m.depth);
        m.y(ny * 36 * m.depth);
      }
    };
    if (movers.length) window.addEventListener("pointermove", onMove, { passive: true });

    return () => {
      window.removeEventListener("pointermove", onMove);
      ctx.revert();
    };
  }, []);

  // Entrance after the intro
  useEffect(() => {
    if (!introDone || prefersReducedMotion()) return;
    const { gsap } = ensureGsap();
    const tl = gsap.timeline();
    tl.to(cupEnterRef.current, {
      autoAlpha: 1,
      yPercent: 0,
      scale: 1,
      rotation: -6,
      duration: 1.5,
      ease: "expo.out",
      delay: 0.25,
    }).to(
      stageRef.current?.querySelectorAll("[data-floater]") ?? [],
      { autoAlpha: 1, scale: 1, duration: 1.2, stagger: 0.12, ease: "back.out(1.6)" },
      0.35,
    );
    return () => {
      tl.kill();
    };
  }, [introDone]);

  // Liquid warp on manifesto words near the cup / cursor
  useEffect(() => {
    const section = statementRef.current;
    const text = statementTextRef.current;
    if (!section || !text || prefersReducedMotion()) return;
    const { gsap, ScrollTrigger } = ensureGsap();
    const spans = Array.from(text.querySelectorAll<HTMLElement>("[data-word]"));
    const disp = spans.map((_, i) => section.querySelector<SVGFEDisplacementMapElement>(`#warp-${i} feDisplacementMap`));
    const turb = spans.map((_, i) => section.querySelector<SVGFETurbulenceElement>(`#warp-${i} feTurbulence`));
    const cur = spans.map(() => 0);
    const mouse = { x: -9999, y: -9999 };
    const onMove = (e: PointerEvent) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
    };
    const falloff = (d: number, r: number) => {
      const t = Math.max(0, 1 - d / r);
      return t * t * (3 - 2 * t);
    };
    const tick = (time: number) => {
      const cupR = cupImgRef.current?.getBoundingClientRect();
      const cx = cupR ? cupR.left + cupR.width / 2 : -9999;
      const cy = cupR ? cupR.top + cupR.height / 2 : -9999;
      const cupRadius = cupR ? Math.max(cupR.width, cupR.height) * 0.75 : 1;
      spans.forEach((span, i) => {
        const r = span.getBoundingClientRect();
        const wx = r.left + r.width / 2;
        const wy = r.top + r.height / 2;
        const infl = Math.max(
          falloff(Math.hypot(wx - mouse.x, wy - mouse.y), 280),
          0.4 * falloff(Math.hypot(wx - cx, wy - cy), cupRadius),
        );
        const value = (cur[i] ?? 0) + (infl * 55 - (cur[i] ?? 0)) * 0.12;
        cur[i] = value;
        if (value > 0.4) {
          disp[i]?.setAttribute("scale", value.toFixed(1));
          turb[i]?.setAttribute(
            "baseFrequency",
            `${(0.01 + 0.004 * Math.sin(time * 1.3 + i)).toFixed(4)} ${(0.035 + 0.012 * Math.cos(time + i)).toFixed(4)}`,
          );
          span.style.filter = `url(#warp-${i})`;
        } else if (span.style.filter) {
          span.style.filter = "";
        }
      });
    };
    let active = false;
    const st = ScrollTrigger.create({
      trigger: section,
      start: "top bottom",
      end: "bottom top",
      onToggle: (self) => {
        if (self.isActive && !active) {
          active = true;
          gsap.ticker.add(tick);
        } else if (!self.isActive && active) {
          active = false;
          gsap.ticker.remove(tick);
        }
      },
    });
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => {
      st.kill();
      gsap.ticker.remove(tick);
      window.removeEventListener("pointermove", onMove);
    };
  }, []);

  return (
    <div ref={stageRef} className="relative">
      {/* Pinned hero cup */}
      <div aria-hidden className="pointer-events-none absolute inset-0 z-20">
        <div className="sticky top-0 flex h-screen items-center justify-center overflow-hidden">
          <div ref={cupScrollRef} className="will-change-transform">
            <div data-depth="0.6">
              <div ref={cupEnterRef}>
                <div data-bob>
                  <img
                    ref={cupImgRef}
                    src={CUPS.mango}
                    alt=""
                    className="drop-cup h-[38vh] w-auto translate-y-[4vh] md:h-[50vh]"
                    fetchPriority="high"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 1 · Hero */}
      <section id="top" className="relative h-[200vh]" aria-label="Brisk Coffee Hanley">
        <div className="sticky top-0 h-screen overflow-hidden bg-plum-glow">
          {FLOATERS.map((f) => (
            <div key={f.src} className={cn("absolute", f.pos, f.layer)} data-depth={f.depth}>
              <div data-floater>
                <div data-bob>
                  <img
                    src={f.src}
                    alt={f.alt}
                    className={cn("drop-cup w-auto", f.size)}
                    style={{ rotate: `${f.rot}deg` }}
                  />
                </div>
              </div>
            </div>
          ))}

          <div ref={heroContentRef} className="brisk-hero-content absolute inset-0 z-[2] flex flex-col items-center text-center">
            <p className="label-mono mb-1 text-cream/70">{HERO.kicker}</p>
            <GoogleRating className="mb-2 rounded-full bg-ink/55 px-3 py-1 text-lime backdrop-blur-sm md:mb-4" />
            <div className="relative" data-depth="-0.25">
              <SplitReveal
                as="h1"
                text={HERO.title}
                mode="mount"
                play={introDone}
                stagger={0.025}
                className="headline brisk-hero-title text-cream"
              />
              <span className="script absolute -bottom-[14%] right-[-4%] z-[30] -rotate-[8deg] text-[14vw] text-lime md:text-[6vw]">
                coffee
              </span>
            </div>
            <div className="absolute inset-x-0 bottom-6 flex flex-col-reverse items-start gap-6 px-5 text-left md:bottom-8 md:flex-row md:items-end md:justify-between md:px-10">
              <p className="brisk-hero-copy max-w-[19rem] text-cream/85 md:max-w-[19rem]">{HERO.sub}</p>
              <div className="flex flex-wrap gap-3 md:gap-6">
                <Pill size="md" href={ORDER_URL} external ariaLabel="Order online (opens Brisk's ordering page)">
                  Order online ↗
                </Pill>
                <Pill size="md" variant="cream" onClick={openMenu}>
                  View menu
                </Pill>
                <Pill size="md" variant="cream" className="hidden sm:inline-flex" onClick={() => go("/visit")}>
                  Visit us
                </Pill>
              </div>
            </div>
          </div>

          <div
            ref={wipeRef}
            className="absolute inset-0 z-[5] bg-cream"
            style={{ clipPath: "circle(0% at 50% 55%)" }}
          />
        </div>
      </section>

      {/* 2 · Flavor marquee */}
      <section
        className="relative flex h-screen flex-col justify-center gap-[5vh] overflow-hidden bg-cream text-ink"
        aria-label="On the menu"
      >
        <p className="label-mono absolute left-5 top-24 md:left-10">(01) On the menu — made fresh daily</p>
        <div ref={row1Ref} className="headline text-outline flex w-max whitespace-nowrap text-[22vw] md:text-[15vw]">
          <MarqueeRow words={MARQUEE_WORDS} />
        </div>
        <div ref={row2Ref} className="headline text-outline flex w-max whitespace-nowrap text-[22vw] md:text-[15vw]">
          <MarqueeRow words={[...MARQUEE_WORDS].reverse()} />
        </div>
        <p className="label-mono absolute bottom-10 right-5 md:right-10">Scroll faster. It goes faster.</p>
      </section>

      {/* 3 · About */}
      <section
        ref={statementRef}
        id="manifesto"
        className="relative flex min-h-[150vh] items-center overflow-hidden bg-cream text-ink"
      >
        <div aria-hidden className="pointer-events-none absolute inset-x-0 top-0">
          {BERRIES.map((b, i) => (
            <span
              key={i}
              className="berry berry-fall absolute top-0"
              style={
                {
                  left: b.left,
                  width: b.size,
                  height: b.size,
                  "--dur": b.dur,
                  "--delay": b.delay,
                  "--drift": b.drift,
                } as CSSProperties
              }
            />
          ))}
        </div>
        <div className="relative mx-auto w-full max-w-[96rem] px-5 py-40 text-center md:px-10">
          <p className="label-mono mb-10">(02) About Brisk</p>
          <p
            ref={statementTextRef}
            aria-label={STATEMENT}
            className="headline text-[15vw] leading-[0.9] md:text-[9.5vw]"
          >
            {words.map((w, i) => (
              <span key={i} aria-hidden>
                <span data-word className="inline-block">
                  {w}
                </span>{" "}
              </span>
            ))}
          </p>
          <p className="label-mono mx-auto mt-12 max-w-md leading-relaxed">
            {ABOUT_LINE}
          </p>
        </div>
        <svg aria-hidden className="absolute h-0 w-0">
          <defs>
            {words.map((_, i) => (
              <filter key={i} id={`warp-${i}`} x="-20%" y="-30%" width="140%" height="160%">
                <feTurbulence type="fractalNoise" baseFrequency="0.01 0.035" numOctaves={2} seed={i + 1} result="noise" />
                <feDisplacementMap in="SourceGraphic" in2="noise" scale={0} xChannelSelector="R" yChannelSelector="G" />
              </filter>
            ))}
          </defs>
        </svg>
      </section>
    </div>
  );
}
