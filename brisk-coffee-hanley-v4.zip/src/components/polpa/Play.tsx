import { useEffect, useRef } from "react";
import type MatterNS from "matter-js";
import { cn } from "@/lib/utils";
import { FRUIT, PLAY_FRUITS, SMALL_SCREEN_FRUIT, STICKERS } from "./data";
import { ensureGsap, prefersReducedMotion } from "./motion";
import { pillVariants } from "./Pill";
import { SplitReveal } from "./SplitReveal";

type Matter = typeof MatterNS;

/** Latte physics pit: grab, throw and bounce pastries off the feature pills. */
export function Play() {
  const sectionRef = useRef<HTMLElement>(null);
  const fruitRefs = useRef<(HTMLImageElement | null)[]>([]);
  const pillRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;
    let disposed = false;
    let started = false;
    let running = false;
    const cleanups: (() => void)[] = [];

    const start = async () => {
      const mod = (await import("matter-js")) as unknown as { default?: Matter } & Matter;
      const M: Matter = mod.default ?? mod;
      await document.fonts?.ready;
      if (disposed) return;
      const { Engine, Bodies, Body, Composite, Constraint } = M;
      const { gsap } = ensureGsap();
      const reduced = prefersReducedMotion();

      const engine = Engine.create({ gravity: { x: 0, y: 1, scale: 0.0012 } });
      engine.positionIterations = 8;
      engine.velocityIterations = 6;
      let W = section.clientWidth;
      let H = section.clientHeight;
      const count = W < 640 ? SMALL_SCREEN_FRUIT : PLAY_FRUITS.length;
      const base = Math.min(Math.max(W * 0.085, 64), 132);

      let statics: MatterNS.Body[] = [];
      const buildStatics = () => {
        Composite.remove(engine.world, statics);
        const t = 400;
        statics = [
          Bodies.rectangle(W / 2, H + t / 2, W * 3, t, { isStatic: true }),
          Bodies.rectangle(-t / 2, 0, t, H * 4, { isStatic: true }),
          Bodies.rectangle(W + t / 2, 0, t, H * 4, { isStatic: true }),
          Bodies.rectangle(W / 2, -H - t / 2, W * 3, t, { isStatic: true }),
        ];
        const sr = section.getBoundingClientRect();
        pillRefs.current.forEach((p) => {
          if (!p) return;
          const r = p.getBoundingClientRect();
          const w = p.offsetWidth;
          const h = p.offsetHeight;
          statics.push(
            Bodies.rectangle(r.left + r.width / 2 - sr.left, r.top + r.height / 2 - sr.top, w, h, {
              isStatic: true,
              angle: (Number(p.dataset["angle"] ?? 0) * Math.PI) / 180,
              chamfer: { radius: h / 2 - 1 },
              restitution: 0.7,
            }),
          );
        });
        Composite.add(engine.world, statics);
      };
      buildStatics();

      const items = PLAY_FRUITS.slice(0, count).map((pf, i) => {
        const asset = FRUIT[pf.fruit];
        const w = base * pf.scale;
        const h = w / asset.aspect;
        const x = W * 0.12 + ((i * 0.37) % 1) * W * 0.76;
        const y = reduced ? H - h - 20 - (i % 3) * h : -80 - i * 90;
        const opts = { restitution: 0.55, friction: 0.08, frictionAir: 0.012, density: 0.0016 };
        let body: MatterNS.Body;
        if (asset.shape === "circle") body = Bodies.circle(x, y, (Math.min(w, h) / 2) * 0.95, opts);
        else if (asset.shape === "banana")
          body = Bodies.rectangle(x, y, w * 0.92, h * 0.55, { ...opts, chamfer: { radius: h * 0.25 } });
        else body = Bodies.rectangle(x, y, w * 0.86, h * 0.9, { ...opts, chamfer: { radius: w * 0.4 } });
        Body.setAngle(body, (i % 5) - 2);
        Body.setAngularVelocity(body, ((i % 3) - 1) * 0.05);
        const el = fruitRefs.current[i];
        if (el) {
          el.style.width = `${w}px`;
          el.style.height = `${h}px`;
          el.style.opacity = "1";
        }
        return { body, el, w, h };
      });
      Composite.add(
        engine.world,
        items.map((it) => it.body),
      );

      const render = () => {
        for (const it of items) {
          if (!it.el) continue;
          const { x, y } = it.body.position;
          it.el.style.transform = `translate3d(${x - it.w / 2}px, ${y - it.h / 2}px, 0) rotate(${it.body.angle}rad)`;
        }
      };
      const tick = (_t: number, dt: number) => {
        if (!running) return;
        const steps = dt > 17 ? 2 : 1;
        const step = Math.min(dt / steps, 16.667);
        for (let s = 0; s < steps; s++) Engine.update(engine, step);
        render();
      };
      render();
      gsap.ticker.add(tick);
      cleanups.push(() => gsap.ticker.remove(tick));

      // Drag & throw
      let drag: { c: MatterNS.Constraint; id: number } | null = null;
      const local = (e: PointerEvent) => {
        const r = section.getBoundingClientRect();
        const pad = 30;
        return {
          x: Math.min(Math.max(e.clientX - r.left, pad), W - pad),
          y: Math.min(Math.max(e.clientY - r.top, -H * 0.8), H - pad),
        };
      };
      items.forEach((it) => {
        const el = it.el;
        if (!el) return;
        const down = (e: PointerEvent) => {
          e.preventDefault();
          const p = local(e);
          const b = it.body;
          const c = Constraint.create({
            pointA: p,
            bodyB: b,
            pointB: { x: p.x - b.position.x, y: p.y - b.position.y },
            stiffness: 0.2,
            damping: 0.1,
            length: 0,
          });
          Composite.add(engine.world, c);
          drag = { c, id: e.pointerId };
          el.setPointerCapture(e.pointerId);
          el.dataset["dragging"] = "true";
        };
        const move = (e: PointerEvent) => {
          if (drag && drag.id === e.pointerId) drag.c.pointA = local(e);
        };
        const up = (e: PointerEvent) => {
          if (!drag || drag.id !== e.pointerId) return;
          Composite.remove(engine.world, drag.c);
          drag = null;
          delete el.dataset["dragging"];
        };
        el.addEventListener("pointerdown", down);
        el.addEventListener("pointermove", move);
        el.addEventListener("pointerup", up);
        el.addEventListener("pointercancel", up);
        cleanups.push(() => {
          el.removeEventListener("pointerdown", down);
          el.removeEventListener("pointermove", move);
          el.removeEventListener("pointerup", up);
          el.removeEventListener("pointercancel", up);
        });
      });

      let resizeTimer = 0;
      const onResize = () => {
        window.clearTimeout(resizeTimer);
        resizeTimer = window.setTimeout(() => {
          W = section.clientWidth;
          H = section.clientHeight;
          buildStatics();
          for (const it of items) {
            const { x, y } = it.body.position;
            Body.setPosition(it.body, {
              x: Math.min(Math.max(x, it.w), W - it.w),
              y: Math.min(y, H - it.h),
            });
          }
        }, 200);
      };
      window.addEventListener("resize", onResize);
      cleanups.push(() => {
        window.removeEventListener("resize", onResize);
        Engine.clear(engine);
      });
    };

    const io = new IntersectionObserver(
      ([entry]) => {
        running = Boolean(entry?.isIntersecting);
        if (running && !started) {
          started = true;
          void start();
        }
      },
      { threshold: 0.15 },
    );
    io.observe(section);
    return () => {
      disposed = true;
      io.disconnect();
      cleanups.forEach((fn) => fn());
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      id="why-us"
      aria-label="Why choose Brisk"
      className="relative h-screen min-h-[640px] select-none overflow-hidden bg-mustard text-ink"
    >
      <p className="label-mono absolute left-5 top-24 md:left-10">(03) Why choose us — grab a pastry</p>
      <p className="script absolute right-[6%] top-[12%] rotate-[-8deg] text-[9vw] text-ink md:right-[8%] md:top-[11%] md:text-[4.5vw]">
        made for Hanley
      </p>

      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
        <SplitReveal
          as="h2"
          text={"WHY CHOOSE\nBRISK"}
          className="headline text-[21vw] md:text-[15.5vw]"
          lineClassName="[&:nth-child(2)]:text-tomato"
        />
      </div>

      {STICKERS.map((s, i) => (
        <div
          key={s.label}
          ref={(el) => {
            pillRefs.current[i] = el;
          }}
          data-angle={s.angle}
          className={cn(pillVariants({ variant: s.variant, size: "sticker" }), "absolute", s.position)}
          style={{ rotate: `${s.angle}deg` }}
        >
          {s.label}
        </div>
      ))}

      <div className="absolute inset-0">
        {PLAY_FRUITS.map((pf, i) => (
          <img
            key={i}
            ref={(el) => {
              fruitRefs.current[i] = el;
            }}
            src={FRUIT[pf.fruit].src}
            alt={pf.fruit === "bun" ? "cinnamon bun" : pf.fruit}
            draggable={false}
            data-cursor="hand"
            loading="lazy"
            className="absolute left-0 top-0 touch-none opacity-0 drop-fruit will-change-transform"
          />
        ))}
      </div>

      <p className="label-mono absolute bottom-6 left-1/2 -translate-x-1/2 text-ink/70">
        Drag. Fling. Repeat.
      </p>
    </section>
  );
}
