import { useEffect, useRef, type ReactNode } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";
import { ensureGsap, hasFinePointer, prefersReducedMotion } from "./motion";

export const pillVariants = cva(
  "relative inline-flex select-none items-center justify-center gap-2 whitespace-nowrap rounded-full font-mono font-bold uppercase tracking-[0.12em] shadow-pill transition-colors duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
  {
    variants: {
      variant: {
        lime: "bg-lime text-ink hover:bg-cream",
        ink: "bg-ink text-cream hover:bg-tomato",
        tomato: "bg-tomato text-cream",
        cream: "bg-cream text-ink",
        navy: "bg-navy text-cream",
      },
      size: {
        sm: "h-9 px-4 text-[0.65rem]",
        md: "h-12 px-6 text-xs",
        lg: "h-14 px-8 text-sm md:h-16 md:px-10",
        sticker: "h-11 px-5 text-xs md:h-16 md:px-8 md:text-base",
      },
    },
    defaultVariants: { variant: "lime", size: "md" },
  },
);

/** Pulls its first child toward the cursor while hovering. */
export function Magnetic({
  children,
  strength = 0.35,
  className,
}: {
  children: ReactNode;
  strength?: number;
  className?: string;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    const el = ref.current;
    const target = el?.firstElementChild as HTMLElement | null | undefined;
    if (!el || !target || prefersReducedMotion() || !hasFinePointer()) return;
    const { gsap } = ensureGsap();
    const xTo = gsap.quickTo(target, "x", { duration: 0.6, ease: "elastic.out(1, 0.45)" });
    const yTo = gsap.quickTo(target, "y", { duration: 0.6, ease: "elastic.out(1, 0.45)" });
    const move = (e: PointerEvent) => {
      const r = el.getBoundingClientRect();
      xTo((e.clientX - (r.left + r.width / 2)) * strength);
      yTo((e.clientY - (r.top + r.height / 2)) * strength);
    };
    const leave = () => {
      xTo(0);
      yTo(0);
    };
    el.addEventListener("pointermove", move);
    el.addEventListener("pointerleave", leave);
    return () => {
      el.removeEventListener("pointermove", move);
      el.removeEventListener("pointerleave", leave);
    };
  }, [strength]);
  return (
    <span ref={ref} className={cn("-m-4 inline-block p-4", className)}>
      {children}
    </span>
  );
}

type PillProps = VariantProps<typeof pillVariants> & {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  href?: string;
  /** Opens the link in a new tab (other sites, e.g. the existing order page). */
  external?: boolean;
  ariaLabel?: string;
};

export function Pill({ children, className, onClick, href, external, variant, size, ariaLabel }: PillProps) {
  const cls = cn(pillVariants({ variant, size }), className);
  return (
    <Magnetic>
      {href ? (
        <a
          href={href}
          className={cls}
          aria-label={ariaLabel}
          {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
        >
          {children}
        </a>
      ) : (
        <button type="button" onClick={onClick} className={cls} aria-label={ariaLabel}>
          {children}
        </button>
      )}
    </Magnetic>
  );
}
