import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import { TESTIMONIALS } from "./data";
import { ensureGsap, prefersReducedMotion } from "./motion";

const N = TESTIMONIALS.length;

export function Testimonials() {
  const [active, setActive] = useState(0);
  const [paused, setPaused] = useState(false);
  const stageRef = useRef<HTMLDivElement>(null);
  const first = useRef(true);

  useEffect(() => {
    if (paused || prefersReducedMotion()) return;
    const t = window.setTimeout(() => setActive((a) => (a + 1) % N), 6000);
    return () => window.clearTimeout(t);
  }, [active, paused]);

  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    const stage = stageRef.current;
    if (!stage) return;
    const { gsap } = ensureGsap();
    const reduced = prefersReducedMotion();
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>("[data-quote]").forEach((el, i) => {
        if (i === active)
          gsap.fromTo(el, { autoAlpha: 0, y: reduced ? 0 : 40 }, { autoAlpha: 1, y: 0, duration: 0.9, delay: 0.15, ease: "expo.out" });
        else gsap.to(el, { autoAlpha: 0, y: reduced ? 0 : -20, duration: 0.35, ease: "power2.in" });
      });
    }, stage);
    return () => ctx.revert();
  }, [active]);

  const step = (d: number) => setActive((a) => (a + d + N) % N);

  return (
    <section
      aria-label="Reviews"
      aria-roledescription="carousel"
      className="relative overflow-hidden bg-mustard px-5 py-28 text-ink md:px-10"
      onPointerEnter={() => setPaused(true)}
      onPointerLeave={() => setPaused(false)}
    >
      <div className="mx-auto max-w-6xl">
        <div className="flex items-center justify-between">
          <p className="label-mono">(04) Kind words</p>
          <p className="label-mono" aria-live="polite">
            0{active + 1} / 0{N}
          </p>
        </div>
        <div ref={stageRef} className="relative mt-10 grid min-h-[22rem] md:min-h-[26rem]">
          {TESTIMONIALS.map((t, i) => (
            <figure
              key={t.name}
              data-quote
              aria-hidden={i !== active}
              className="col-start-1 row-start-1"
              style={{ opacity: i === 0 ? 1 : 0, visibility: i === 0 ? "visible" : "hidden" }}
            >
              <span aria-hidden className="script block text-[22vw] leading-[0.5] text-tomato md:text-[10vw]">
                “
              </span>
              <blockquote className="headline text-[9vw] leading-[0.95] md:text-[4.6vw]">{t.quote}</blockquote>
              <figcaption className="mt-8 flex items-center gap-4">
                <span className="script whitespace-nowrap text-4xl text-tomato">{t.name}</span>
                <span className="label-mono text-ink/60">{t.detail}</span>
              </figcaption>
            </figure>
          ))}
        </div>
        <div className="mt-10 flex items-center gap-4">
          <button
            type="button"
            onClick={() => step(-1)}
            aria-label="Previous review"
            className="grid h-12 w-12 place-items-center rounded-full border-2 border-ink/40 transition-colors hover:border-ink hover:bg-ink hover:text-cream"
          >
            ←
          </button>
          <button
            type="button"
            onClick={() => step(1)}
            aria-label="Next review"
            className="grid h-12 w-12 place-items-center rounded-full border-2 border-ink/40 transition-colors hover:border-ink hover:bg-ink hover:text-cream"
          >
            →
          </button>
          <div className="ml-4 flex gap-2">
            {TESTIMONIALS.map((t, i) => (
              <button
                key={t.name}
                type="button"
                aria-label={`Show review ${i + 1}`}
                aria-current={i === active}
                onClick={() => setActive(i)}
                className={cn("h-2 rounded-full bg-ink transition-all duration-500", i === active ? "w-10" : "w-2 opacity-30")}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
