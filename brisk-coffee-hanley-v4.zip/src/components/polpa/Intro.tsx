import { useEffect, useRef, useState } from "react";
import { ensureGsap } from "./motion";

interface Bubble {
  x: number;
  y: number;
  r: number;
  vx: number;
  vy: number;
}

/** Espresso splash screen with glossy crema bubbles that drift away from the cursor. */
export function Intro({ done }: { done: boolean }) {
  const rootRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gone, setGone] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    let raf = 0;
    let w = 0;
    let h = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const mouse = { x: -9999, y: -9999 };
    let bubbles: Bubble[] = [];

    const resize = () => {
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.round(Math.min(48, (w * h) / 22000));
      bubbles = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        r: 6 + Math.random() * 22,
        vx: (Math.random() - 0.5) * 0.3,
        vy: -0.15 - Math.random() * 0.45,
      }));
    };

    const draw = () => {
      ctx.clearRect(0, 0, w, h);
      for (const b of bubbles) {
        const dx = b.x - mouse.x;
        const dy = b.y - mouse.y;
        const d = Math.hypot(dx, dy);
        if (d < 180 && d > 0.01) {
          const f = (1 - d / 180) * 0.9;
          b.vx += (dx / d) * f;
          b.vy += (dy / d) * f;
        }
        b.vx *= 0.94;
        b.vy = b.vy * 0.94 - 0.03;
        b.x += b.vx;
        b.y += b.vy;
        if (b.y < -40) {
          b.y = h + 40;
          b.x = Math.random() * w;
        }
        if (b.x < -40) b.x = w + 40;
        if (b.x > w + 40) b.x = -40;

        const g = ctx.createRadialGradient(b.x - b.r * 0.35, b.y - b.r * 0.4, b.r * 0.05, b.x, b.y, b.r);
        g.addColorStop(0, "#f7f2ea");
        g.addColorStop(0.15, "#d9c2a3");
        g.addColorStop(0.55, "#5c3a21");
        g.addColorStop(1, "#181818");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
        ctx.fill();
      }
      raf = requestAnimationFrame(draw);
    };

    const onMove = (e: PointerEvent) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
    };
    resize();
    draw();
    window.addEventListener("resize", resize);
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("pointermove", onMove);
    };
  }, []);

  useEffect(() => {
    if (!done || !rootRef.current) return;
    const { gsap } = ensureGsap();
    const tween = gsap.to(rootRef.current, {
      autoAlpha: 0,
      duration: 0.9,
      ease: "power2.inOut",
      onComplete: () => setGone(true),
    });
    return () => {
      tween.kill();
    };
  }, [done]);

  if (gone) return null;

  return (
    <div
      ref={rootRef}
      role="status"
      aria-label="Loading Brisk Coffee Hanley"
      className="fixed inset-0 z-[90] flex items-center justify-center bg-plum-deep"
    >
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" aria-hidden />
      <div className="pointer-events-none relative text-center">
        <p className="headline text-[22vw] text-cream md:text-[11vw]">
          Brisk<span className="text-lime">.</span>
        </p>
        <p className="label-mono mt-4 text-lime">Grinding the beans…</p>
      </div>
    </div>
  );
}
