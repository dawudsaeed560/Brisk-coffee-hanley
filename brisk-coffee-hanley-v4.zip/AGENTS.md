<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules

- Landing page lives in `src/components/polpa/`; copy, flavors, stickers and asset paths live in `data.ts` so content changes stay out of components.
- Product images are plain files in `public/images/` with stable names, so they can be swapped by replacing the file; gallery photos are CDN `.asset.json` pointers in `src/assets/gallery/`, imported in `data.ts`, because they are real shop photos rather than layout art.
- matter-js and ogl are dynamic-imported inside effects (browser-only); GSAP and Lenis go through `motion.ts` (`ensureGsap`, `smoothScrollTo`) so every scroll effect shares one Lenis instance; `smoothScrollTo` glides short hops and fades a veil for long jumps so navigation never races through pinned scenes.
- Decorative "random" values use the integer `seeded()` hash, never `Math.random`/`Math.sin` in render, so server and browser HTML match.
- The page transition, custom cursor and menu pop-up (`MenuDialogProvider`, opened via `useOpenMenu`) are mounted in `__root.tsx` so they persist across routes.
- The main page keeps the original section order; extra content (full menu, gallery, reviews, location) lives in the menu pop-up and the `/visit` route instead of new landing sections.
- Business facts (prices, perks, Google rating, hours, reviews, order URL) live in `data.ts` with their source noted, and are covered by tests in `src/test/flavors.test.ts`, so nothing unverified reaches the page.
- While the site is a sample for the owner, `__root.tsx` keeps a robots `noindex` meta, a visible "sample redesign" label, and `public/robots.txt` disallows all; remove all three together at launch.
